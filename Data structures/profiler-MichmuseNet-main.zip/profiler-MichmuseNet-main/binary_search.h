#ifndef BINARY_SEARCH_H
#define BINARY_SEARCH_H
#include <vector>
#include <string>

template<typename T>
void merge(std::vector<T>& arr,int low,int mid,int high);
template<typename T>
void mergeSort(std::vector<T>& arr,int low,int high);
template<typename T>
void sortData(std::vector<T>& arr);
template <typename T>
int binarySearchIterative(const std::vector<T>& data,const T& target);
template <typename T>
int binarySearchRecursive(const std::vector<T>& data,const T& target, int low, int high);
template <typename T>
int binarySearchRecursive(const std::vector<T>& data,const T& target);
#endif
