#include "profiler.h"
#include <iostream>
#include <chrono>
#include <string>
#include <fstream>
#include <sstream>

static std::chrono::high_resolution_clock::time_point g_startTime;
static std::string g_programName;
void setProgramName(const std::string& name){g_programName=name;}
void startProfiling(){g_startTime=std::chrono::high_resolution_clock::now();}
static long getMemoryUsageMB(){
#ifdef __linux__
    std::ifstream f("/proc/self/status");
    std::string line;
    while(std::getline(f,line)){
        if(line.rfind("VmRSS:",0)==0){
            std::istringstream iss(line);
            std::string key,unit;
            long kb=0;
            if(iss>>key>>kb>>unit)return kb/1024;
        }
    }
#endif
    return 0;
}
void stopProfiling(){
    auto end=std::chrono::high_resolution_clock::now();
    auto duration_ns=std::chrono::duration_cast<std::chrono::nanoseconds>(end-g_startTime).count();
    long memMB=getMemoryUsageMB();
    auto padRight=[](const std::string& s,size_t width){
        return(s.size()>=width)?s.substr(0,width):s+std::string(width-s.size(),' ');
    };
    std::cout<<"====================================\n"
             <<"|"<<padRight(" My Profiler ",16)
             <<"|"<<padRight(" "+g_programName+" ",17)<<"|\n"
             <<"|"<<std::string(16,'-')<<"|"<<std::string(17,'-')<<"|\n"
             <<"|"<<padRight(" Execution Time ",16)
             <<"|"<<padRight(" "+std::to_string(duration_ns)+" ns ",17)<<"|\n"
             <<"|"<<padRight(" Memory Usage ",16)
             <<"|"<<padRight(" "+std::to_string(memMB)+" MB ",17)<<"|\n"
             <<"====================================\n";
}
