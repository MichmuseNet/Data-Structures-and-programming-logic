#ifndef PROFILER_H
#define PROFILER_H

#include <string>

void setProgramName(const std::string& name);
void startProfiling();
void stopProfiling();

#endif
