#include "sequential_search.h"
#include <vector>
#include <string>
template int sequentialSearch<int>(const std::vector<int>&,const int&);
template int sequentialSearch<double>(const std::vector<double>&,const double&);
template int sequentialSearch<std::string>(const std::vector<std::string>&,const std::string&);
