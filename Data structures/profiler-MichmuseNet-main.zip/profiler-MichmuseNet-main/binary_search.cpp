#include "binary_search.h"
#include <string>
#include <vector>
template<typename T>
void merge(std::vector<T>& arr,int low,int mid,int high){
    std::vector<T> temp;temp.reserve(high-low+1);
    int left=low,right=mid+1;
    while(left<=mid&&right<=high){
        if(arr[left]<=arr[right])temp.push_back(arr[left++]);
        else temp.push_back(arr[right++]);
    }
    while(left<=mid)temp.push_back(arr[left++]);
    while(right<=high)temp.push_back(arr[right++]);
    for(int i=low;i<=high;++i)arr[i]=temp[i-low];
}
template<typename T>
void mergeSort(std::vector<T>& arr,int low,int high){
    if(low<high){
        int mid=low+(high-low)/2;
        mergeSort(arr,low,mid);
        mergeSort(arr,mid+1,high);
        merge(arr,low,mid,high);
    }
}
template<typename T>
void sortData(std::vector<T>& arr){
    if(!arr.empty())mergeSort(arr,0,static_cast<int>(arr.size())-1);
}
template<typename T>
int binarySearchIterative(const std::vector<T>& data,const T& target){
    int low=0,high=static_cast<int>(data.size())-1;
    while(low<=high){
        int mid=low+(high-low)/2;
        if(data[mid]==target)return mid;
        else if(data[mid]<target)low=mid+1;
        else high=mid-1;
    }
    return -1;
}
template<typename T>
int binarySearchRecursive(const std::vector<T>& data,const T& target,int low,int high){
    if(low>high)return -1;
    int mid=low+(high-low)/2;
    if(data[mid]==target)return mid;
    else if(data[mid]<target)return binarySearchRecursive(data,target,mid+1,high);
    else return binarySearchRecursive(data,target,low,mid-1);
}
template<typename T>
int binarySearchRecursive(const std::vector<T>& data,const T& target){
    return binarySearchRecursive(data,target,0,static_cast<int>(data.size())-1);
}
template void sortData<int>(std::vector<int>&);
template void sortData<double>(std::vector<double>&);
template void sortData<std::string>(std::vector<std::string>&);
template int binarySearchIterative<int>(const std::vector<int>&,const int&);
template int binarySearchIterative<double>(const std::vector<double>&,const double&);
template int binarySearchIterative<std::string>(const std::vector<std::string>&,const std::string&);
template int binarySearchRecursive<int>(const std::vector<int>&,const int&);
template int binarySearchRecursive<double>(const std::vector<double>&,const double&);
template int binarySearchRecursive<std::string>(const std::vector<std::string>&,const std::string&);
