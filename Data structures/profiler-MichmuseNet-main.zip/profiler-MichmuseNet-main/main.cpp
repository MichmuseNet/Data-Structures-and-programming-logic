// Coding 4.1 - Search Algorithms and Profiler
#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<cctype>
#include"profiler.h"
#include"sequential_search.h"
#include"binary_search.h"
template<typename T>
bool loadData(const std::string&filename,std::vector<T>&out){
    std::ifstream fin(filename);
    if(!fin.is_open())return false;
    T v;
    while(fin>>v)out.push_back(v);
    return true;
}
template<typename T>
bool runSearch(const std::string&inputFile,const std::string&targetStr,const std::string&algorithm){
    std::vector<T>data;
    if(!loadData<T>(inputFile,data)){
        std::cerr<<"Can't open "<<inputFile<<"\n";
        return false;
    }
    T target{};
    if constexpr(std::is_same<T,int>::value)target=std::stoi(targetStr);
    else if constexpr(std::is_same<T,double>::value)target=std::stod(targetStr);
    else target=targetStr;
    if(algorithm!="--sequential-search")sortData(data);
    int idx=-1;
    if(algorithm=="--sequential-search")idx=sequentialSearch(data,target);
    else if(algorithm=="--binary-search")idx=binarySearchIterative(data,target);
    else if(algorithm=="--recursive-binary-search")idx=binarySearchRecursive(data,target);
    return(idx!=-1);
}
int main(int argc,char*argv[]){
    if(argc<5){
        std::cerr<<"Usage: ./main --input <file> --target <value> [--sequential-search | --binary-search | --recursive-binary-search]\n";
        return 1;
    }
    std::string inputFile,targetStr,algorithm;
    for(int i=1;i<argc;++i){
        std::string a=argv[i];
        if(a=="--input"&&i+1<argc)inputFile=argv[++i];
        else if(a=="--target"&&i+1<argc)targetStr=argv[++i];
        else if(a=="--sequential-search"||a=="--binary-search"||a=="--recursive-binary-search")algorithm=a;
    }
    if(inputFile.empty()||targetStr.empty()||algorithm.empty()){
        std::cerr<<"Error: check --input, --target and type of search\n";
        return 1;
    }
    setProgramName(argv[0]);
    startProfiling();
    bool found=false;
    if(inputFile.find("integers")!=std::string::npos)found=runSearch<int>(inputFile,targetStr,algorithm);
    else if(inputFile.find("floats")!=std::string::npos)found=runSearch<double>(inputFile,targetStr,algorithm);
    else if(inputFile.find("strings")!=std::string::npos)found=runSearch<std::string>(inputFile,targetStr,algorithm);
    else{
        std::ifstream fin(inputFile);
        if(!fin.is_open()){std::cerr<<"Can't open "<<inputFile<<"\n";return 1;}
        std::string first;fin>>first;fin.close();
        bool hasAlpha=false,hasDot=false;
        for(char c:first){
            if(std::isalpha(static_cast<unsigned char>(c))){hasAlpha=true;break;}
            if(c=='.')hasDot=true;
        }
        if(hasAlpha)found=runSearch<std::string>(inputFile,targetStr,algorithm);
        else if(hasDot)found=runSearch<double>(inputFile,targetStr,algorithm);
        else found=runSearch<int>(inputFile,targetStr,algorithm);
    }
    std::string algName=(algorithm=="--sequential-search")?"Sequential Search":(algorithm=="--binary-search")?"Iterative Binary Search":"Recursive Binary Search";
    std::string dataType=(inputFile.find("integers")!=std::string::npos)?"Integers":(inputFile.find("floats")!=std::string::npos)?"Floats":(inputFile.find("strings")!=std::string::npos)?"Strings":"Unknown";
    std::cout<<"Search Algorithm : "<<algName<<"\n"
             <<"Input File       : "<<inputFile<<"\n"
             <<"Data Values Type : "<<dataType<<"\n"
             <<"Target Value     : "<<targetStr<<"\n"
             <<"Result           : "<<(found?"Found":"Not Found")<<"\n";
    stopProfiling();
    return 0;
}
