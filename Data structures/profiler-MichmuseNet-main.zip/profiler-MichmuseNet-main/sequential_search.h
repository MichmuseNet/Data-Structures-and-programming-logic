#pragma once
#include <vector>
template <typename T>
int sequentialSearch(const std::vector<T>& data,const T& target) {
    for (size_t i=0;i<data.size();++i)
        if (data[i]==target) return static_cast<int>(i);
    return -1;
}
