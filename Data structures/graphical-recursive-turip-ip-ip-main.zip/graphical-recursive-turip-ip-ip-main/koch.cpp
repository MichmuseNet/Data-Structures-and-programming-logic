#include <iostream>
#include <fstream>//edit files
#include <cmath>
#include <cstdlib>
using namespace std;

//koch crve
struct point {
    double x,y;
};
void WriteLine(ofstream &out,point p1,point p2) {
    out <<"("<<(int)p1.x<<","<<(int)p1.y<<")"
        <<"("<<(int)p2.x<<","<<(int)p2.y<<")"<<endl;
}
void koch(ofstream &out,point p1,point p2,int depth) {
    if (depth==0) {
        WriteLine(out,p1,p2);
        return;
    }
    
    
    point a, b,c;
    a.x=(2*p1.x+p2.x)/3;
    a.y=(2* p1.y+p2.y)/3;
    b.x=(p1.x+ 2*p2.x)/3;
    b.y=(p1.y + 2*p2.y)/3;
    double angle=M_PI/3.0;
    c.x =(b.x-a.x)*cos(angle) -(b.y-a.y)*sin(angle)+a.x;
    c.y=(b.x-a.x)*sin(angle)+(b.y-a.y)*cos(angle)+a.y;

    koch(out,p1,a,depth-1);
    koch(out,a,c,depth-1);
    koch(out,c,b,depth-1);
    koch(out,b,p2,depth-1);

}



int main(int argc,char* argv[]) { 
    if (argc!=3) {
        cerr<<"use: "<< argv[0]<<" <depth> <generated_file>"<< endl;
        return 1;
    }
    int depth=atoi(argv[1]);
    string file=argv[2];
    ofstream out(file);
    if (!out) {
        cerr<< "error, can't open the file"<< endl;
        return 1;
    }
    point start={100,800};
    point end={900,800};
    koch(out,start,end,depth);
    out.close();
    cout<<"generated file: "<<file<<endl;
    return 0;
}
