#include <iostream> // Required for input/output operations (std::cout)
#include <cstdlib>  // Required for atoi (converts string to integer)
#include <chrono> //libreria para manejar tiempo

int iterativesum(int n) {
    int sum=0;
    for (int i=1; i<=n; ++i) sum+=i;
    return sum;
}

int recursivesum(int n) {
    return (n==0) ? 0 : n+recursivesum(n-1);
}

int directsum(int n) {
    return n*(n+1)/2;
}

template<typename Func> //funcion que mide y muestra el resultado y el tempo de ejecucion
void print(Func f,int n,const std::string& label) {
    auto inicio=std::chrono::high_resolution_clock::now();
    int resultado=f(n);
    auto fin=std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed=fin-inicio;

    std::cout << "# "<<label<<"with n="<<n<<"\n"
              << " -Resultado:"<<resultado<<"\n"
              << " -tiempo:"<<elapsed.count()<<"seconds\n";
}

int main(int argc,char *argv[]) {
    // argc is the argument count, including the program name itself.
    // argv is an array of strings (char pointers), where each element
    // is a command-line argument.

    // Check if exactly one argument (besides the program name) is provided.
    if (argc != 2) {
        std::cerr << "Uso: " << argv[0] << " <integer>\n";
        return 1;
    }

    // Convert the first command-line argument (argv[1]) to an integer.
    // argv[0] is the program's name.
    int n = std::atoi(argv[1]);
    std::cout << "numero recibido: " << n << std::endl;

    // Print the received integer.
    print(iterativesum,n,"Iterative Sum"); //imprme resultado
    print(recursivesum,n,"Recursive Sum");
    print(directsum,n,"Direct Sum");

    return 0; // Indicate successful execution
}
