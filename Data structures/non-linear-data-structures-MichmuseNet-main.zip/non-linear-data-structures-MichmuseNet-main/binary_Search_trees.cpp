#include <iostream>
#include <queue>//
#include <string>//
using namespace std;

struct Node {
    int key;
    Node* left;
    Node* right;
    Node(int item) {
        key = item;
        left = NULL;
        right = NULL;
    }
};
// A utility function to insert a new node with 
// the given key
Node* insert(Node* node, int key) {
    // If the tree is empty, return a new node
    if (node == NULL)
        return new Node(key);
    // If the key is already present in the tree,
    // return the node
    if (node->key == key)
        return node;
    // Otherwise, recur down the tree/ If the key
    // to be inserted is greater than the node's key,
    // insert it in the right subtree
    if (key < node->key)
        node->left = insert(node->left, key);
    // If the key to be inserted is smaller than 
    // the node's key,insert it in the left subtree
    else
        node->right = insert(node->right, key);

    // Return the (unchanged) node pointer
    return node;
}
// Function to find the in-order successor (smallest in right subtree)
Node* findMin(Node* node) {
    Node* current = node;
    while (current && current->left != nullptr) {
        current = current->left;
    }
    return current;
}
// Function to find the in-order predecessor (largest in left subtree)
Node* findMax(Node* node) {
    Node* current = node;
    while (current && current->right != nullptr) {
        current = current->right;
    }
    return current;
}

Node* search(Node* root, int val) {
    if (root == nullptr || root->key == val)
        return root;
    if (val < root->key)
        return search(root->left, val);
    return search(root->right, val);
}

Node* findSuccessor(Node* root, Node* target) {
    if (target->right != nullptr)
        return findMin(target->right);

    Node* succ = nullptr;
    while (root != nullptr) {
        if (target->key < root->key) {
            succ = root;
            root = root->left;
        } else if (target->key > root->key) {
            root = root->right;
        } else break;
    }
    return succ;
}

Node* findPredecessor(Node* root, Node* target) {
    if (target->left != nullptr)
        return findMax(target->left);

    Node* pred = nullptr;
    while (root != nullptr) {
        if (target->key > root->key) {
            pred = root;
            root = root->right;
        } else if (target->key < root->key) {
            root = root->left;
        } else break;
    }
    return pred;
}
// Function to delete a node from the BST
Node* deleteNode(Node* root, int key, bool useSuccessor = true) {
    // Base case: tree is empty or key not found
    if (root == nullptr)
        return root;
    // Traverse the tree to find the node to delete
    if (key < root->key)
        root->left = deleteNode(root->left, key, useSuccessor);
    else if (key > root->key)
        root->right = deleteNode(root->right, key, useSuccessor);
    else {
        if (root->left == nullptr) {
            Node* temp = root->right;
            delete root;
            return temp;
        }
        else if (root->right == nullptr) {
            Node* temp = root->left;
            delete root;
            return temp;
        }

        if (useSuccessor) {
            Node* temp = findMin(root->right);
            root->key = temp->key;
            root->right = deleteNode(root->right, temp->key, useSuccessor);
        } else {
            Node* temp = findMax(root->left);
            root->key = temp->key;
            root->left = deleteNode(root->left, temp->key, useSuccessor);
        }
    }
    return root;
}
// A utility function to do inorder tree traversal
void inorder(Node* root) {
    if (root != nullptr) {
        inorder(root->left);
        cout << root->key << " ";
        inorder(root->right);
    }
}

void preorder(Node* root) {
    if (root != nullptr) {
        cout << root->key << " ";
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(Node* root) {
    if (root != nullptr) {
        postorder(root->left);
        postorder(root->right);
        cout << root->key << " ";
    }
}

void levelorder(Node* root) {
    if (root == nullptr)
        return;

    queue<Node*> q;
    q.push(root);
    int level = 0;

    while (!q.empty()) {
        int size = q.size();
        level++;
        cout << "level " << level << ": ";
        for (int i = 0; i < size; i++) {
            Node* current = q.front();
            q.pop();
            cout << current->key << " ";
            if (current->left)
                q.push(current->left);
            if (current->right)
                q.push(current->right);
        }
        cout << endl;
    }
    cout << "total of levels:  " << level << endl;
}
// Driver program to test the above functions
int main() {
    // Creating the following BST
    //      50
    //     /  \
    //    30   70
    //   / \   / \
    //  20 40 60 80
    Node* root = new Node(50);
    root = insert(root, 30);
    root = insert(root, 20);
    root = insert(root, 40);
    root = insert(root, 70);
    root = insert(root, 60);
    root = insert(root, 80);

    cout << "Inorder before delete:\n";
    inorder(root);
    cout << endl;

    root = deleteNode(root, 70, true);
    cout << "Inorder after deelte using successor:\n";
    inorder(root);
    cout << endl;

    Node* node40 = search(root, 40);
    Node* succ = findSuccessor(root, node40);
    Node* pred = findPredecessor(root, node40);
    cout << "\nsuccessor of 40: " << (succ ? to_string(succ->key) : "none") << endl;
    cout << "Predecessor of 40: " << (pred ? to_string(pred->key) : "none") << endl;

    cout << "\nTree traversals:\n";
    cout << "Preorder: ";
    preorder(root);
    cout << "\nInorder: ";
    inorder(root);
    cout << "\nPostorder: ";
    postorder(root);
    cout << "\nLevelorder:\n";
    levelorder(root);

    return 0;
}
