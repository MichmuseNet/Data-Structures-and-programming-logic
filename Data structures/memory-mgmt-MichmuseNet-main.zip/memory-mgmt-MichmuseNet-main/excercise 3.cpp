//thing 3: scope matters
using namespace std;
#include <iostream>

int* foo(){
  int a = 700, *b = &a;
  return b;
}

int main(){
    int *ptr =foo();
    cout<<*ptr<<endl;
    return 0;
}