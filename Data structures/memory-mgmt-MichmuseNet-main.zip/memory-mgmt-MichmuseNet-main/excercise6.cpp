//thing 6: make sure taht you point to something
using namespace std;
#include <iostream>
int main(){
    int *v=NULL;

    cout<<"error:"<<endl;
    cout<<*v<<endl;
    
}
//If it doesn't point to a space, what is accessed?
// it causes a runtime error (segmentation fault) because v is a null pointer and dereferencing it (trying to access the value it points to) is invalid. This can lead to crashes or other unpredictable behavior.