//thing 8: new is not the only option
using namespace std;
#include <iostream>

int main(){
    int *p, q = 10, *r;
    p = &q;
    r = p;
    //the difference between p and r is that p has the address of q, and r has the value of p
    cout<<p<<endl;
    cout<<r<<endl;
    cout<<*p<<endl;
    cout<<*r<<endl;
    return 0;
}
//What's the difference between p and r in following examples?
// p is a pointer that holds the address of the variable q, while r is another pointer that is assigned the value of p, meaning r also points to the same address as p. Therefore, both p and r point to the same memory location where q is stored, and dereferencing either pointer (*p or *r) will yield the value of q, which is 10.