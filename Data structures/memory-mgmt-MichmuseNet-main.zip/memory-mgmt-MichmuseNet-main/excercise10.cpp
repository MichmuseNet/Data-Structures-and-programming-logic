//thing 10: operations on reference data
using namespace std;
#include <iostream>

int main(){

    string *a=new string ("my string");
    int *b = new int(3);

    cout<<*b * 5 <<endl;
    cout<<a->size()<<endl;

    return 0;
}