//thing 7: be careful with new
using namespace std;
#include <iostream>

int main(){
    int *p =new int (500);

    cout<<*p<<endl;

    p= new int (1000);

    cout<<*p<<endl;

    return 0;
}
//What happens with the old data?
// The old data (the integer value 500) becomes inaccessible because the pointer p is reassigned to point to a new memory location that holds the value 1000. This results in a memory leak, as the memory allocated for the old data is not freed before p is reassigned. To avoid this, you should delete the old memory before reassigning the pointer, like this: