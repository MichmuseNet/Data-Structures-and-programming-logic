//thing 5: make sure that you delete something
#include <iostream>
using namespace std;
 int main (){
    int *p;
    delete p;
    return 0;
 }
 //if it doesn't point to a space, what is freed up?
   // it causes undefined behavior, because p is an uninitialized pointer that does not point to a valid memory location. Deleting such a pointer can lead to crashes or other unpredictable behavior.
   //no se libera ninguna memoria valida, comportamiento indefinido