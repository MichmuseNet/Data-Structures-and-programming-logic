//excercise 2
#include <iostream>
using namespace std;

int main(){
int *p, *q, *r;
p = new int;
q = r = p;

cout<<"p: "<<*p<<endl;
cout<<"q: "<<*q<<endl;
cout<<"r: "<<*r<<endl;

delete r;
return 0;
}


//questions
//what happens with *p and *q? 
// ambos apuntan a la misma direccion de memoria que r, pero al hacer delete r, se libera esa memoria, por lo que *p y *q quedan apuntando a una direccion de memoria liberada, lo que puede causar comportamiento indefinido si se intenta acceder a ellos despues del delete.