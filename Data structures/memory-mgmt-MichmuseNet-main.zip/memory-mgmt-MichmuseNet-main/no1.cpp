// exercise 1
#include <iostream>
using namespace std;
int main(){
//new reserva el espacio en memoria
    int* a = new int (100000); //new da un memory address que va asignado a una variable pointer 
    cout<< a <<endl;
    delete a; //libera memoria que se asigno con new
    return 0;
}
//questions:
// if we forget to add the delete... no libera memoria, hay fuga de memoria 
// if we put an extra delete... sale error, pointer being freed was not allocated




