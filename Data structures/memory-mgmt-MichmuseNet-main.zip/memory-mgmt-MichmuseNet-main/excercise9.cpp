//thing 9: comparing pointers
using namespace std;
#include<iostream>

int main(){
    int *p, q=10, *r;
    p=&q;
    r=p;

    if (p>3){
        cout<<"p and r point to the same address"<<endl;
    
    }else{
        cout<<"p and r point to different addresses"<<endl;
    }

    return 0;
}
//What about the >, <, >= and <= operators?
// These operators can be used to compare the memory addresses stored in the pointers. The comparison is based on the numerical value of the addresses, not the values they point to. For example, if pointer p points to a lower memory address than pointer r, then p < r will evaluate to true. However, comparing pointers that do not point to elements of the same array (or one past the last element) results in undefined behavior.