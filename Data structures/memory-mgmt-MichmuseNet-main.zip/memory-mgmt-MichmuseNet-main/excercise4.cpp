//thing 4: garbage is different than NULL
using namespace std;
#include <iostream>
int main(){
    int *p, *q=NULL;
    cout<<p<<endl;
    cout<<q<<endl;
    return 0;
}