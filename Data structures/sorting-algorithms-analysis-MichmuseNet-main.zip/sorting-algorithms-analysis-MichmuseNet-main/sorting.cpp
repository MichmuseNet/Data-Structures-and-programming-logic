#include "sorting.h"
#include <algorithm>
#include <cmath>

//bubble sort
template <typename T>
void bubbleSort(std::vector<T>& arr) {
    for (size_t n=arr.size(); n>1;--n) {
        for (size_t i=0;i<n-1;++i) {
            if (arr[i]>arr[i+1])
                std::swap(arr[i],arr[i+1]);
        }
    }
}

//selection sort
template <typename T>
void selectionSort(std::vector<T>& arr) {
    for (size_t i=0;i<arr.size();++i) {
        size_t minIdx=i;
        for (size_t j=i+1;j<arr.size(); ++j)
            if (arr[j]<arr[minIdx]) minIdx=j;
        if (minIdx!=i) std::swap(arr[i],arr[minIdx]);
    }
}

//insertion sort
template <typename T>
void insertionSort(std::vector<T>& arr) {
    for (size_t i=1; i<arr.size(); ++i) {
        T key=arr[i];
        size_t j=i;
        while (j>0&&arr[j-1]>key) {
            arr[j]=arr[j-1];
            --j;
        }
        arr[j]=key;
    }
}

//merge sort
template <typename T>
static void mergeRange(std::vector<T>& arr,size_t l,size_t m,size_t r) {
    std::vector<T> tmp;
    tmp.reserve(r-l+1);
    size_t i=l,j=m+1;
    while (i<=m && j<=r) {
        if (arr[i]<=arr[j]) tmp.push_back(arr[i++]);
        else                  tmp.push_back(arr[j++]);
    }
    while (i<=m) tmp.push_back(arr[i++]);
    while (j<=r) tmp.push_back(arr[j++]);
    for (size_t k=0;k<tmp.size();++k) arr[l+k]=tmp[k];
}
template <typename T>
static void mergeSortRec(std::vector<T>& arr, size_t l,size_t r) {
    if (l >=r) return;
    size_t m=l+(r-l) / 2;
    mergeSortRec(arr,l,m);
    mergeSortRec(arr,m+1,r);
    if (arr[m]<= arr[m+1]) return;
    mergeRange(arr,l,m,r);
}
template <typename T>
void mergeSort(std::vector<T>& arr) {
    if (!arr.empty()) mergeSortRec(arr,0,arr.size()-1);
}

//quick sort
template <typename T>
static size_t partitionQS(std::vector<T>& arr,size_t l,size_t r) {
    T pivot =arr[r];
    size_t i =l;
    for (size_t j=l;j<r;++j) {
        if (arr[j]<=pivot) { std::swap(arr[i],arr[j]); ++i; }
    }
    std::swap(arr[i],arr[r]);
    return i;
}
template <typename T>
static void quickSortRec(std::vector<T>& arr,size_t l,size_t r) {
    if (l>=r) return;
    size_t p=partitionQS(arr,l,r);
    if (p>0) quickSortRec(arr,l,p-1);
    quickSortRec(arr,p+1,r);
}
template <typename T>
void quickSort(std::vector<T>& arr) {
    if (!arr.empty()) quickSortRec(arr,0,arr.size()-1);
}

// shell sort
template <typename T>
void shellSort(std::vector<T>& arr) {
    for (size_t gap = arr.size()/2; gap>0; gap/=2) {
        for (size_t i=gap;i<arr.size();++i) {
            T temp= arr[i];
            size_t j= i;
            while (j >=gap&&arr[j-gap]>temp) {
                arr[j]=arr[j-gap];
                j-=gap;
            }
            arr[j]=temp;
        }
        if (gap==1) break;
    }
}

// heap sort
template <typename T>
static void heapify(std::vector<T>& arr,size_t n,size_t i) {
    size_t largest =i;
    size_t l=2*i+1,r=2*i+2;
    if (l<n && arr[l]>arr[largest]) largest=l;
    if (r<n && arr[r]>arr[largest]) largest=r;
    if (largest!=i) {
        std::swap(arr[i],arr[largest]);
        heapify(arr,n,largest);
    }
}
template <typename T>
void heapSort(std::vector<T>& arr) {
    size_t n=arr.size();
    if (n ==0) return;
    for (int i=static_cast<int>(n/2)-1;i>=0;--i) heapify(arr,n,i);
    for (size_t i=n-1;i>0;--i) {
        std::swap(arr[0],arr[i]);
        heapify(arr,i,0);
    }
}

// bucket sort
template <typename T>
void bucketSort(std::vector<T>& arr) {
    if (arr.empty()) return;

    T mn=*std::min_element(arr.begin(),arr.end());
    T mx=*std::max_element(arr.begin(),arr.end());

    T shift=0;
    if (mn<0) {
        shift=-mn;
        for (auto& v : arr) v+=shift;
        mx+= shift;
    }

    size_t bucketCount= std::max<size_t>(1,static_cast<size_t>(std::sqrt(arr.size())));
    size_t range= static_cast<size_t>(mx)+ 1;
    size_t bucketSize = std::max<size_t>(1,range/bucketCount+(range%bucketCount!=0));

    std::vector<std::vector<T>> buckets(bucketCount);
    for (T v : arr) {
        size_t idx=std::min(bucketCount-1,static_cast<size_t>(v)/bucketSize);
        buckets[idx].push_back(v);
    }

    arr.clear();
    for (auto& b : buckets) {
        std::sort(b.begin(),b.end());
        arr.insert(arr.end(),b.begin(),b.end());
    }

    if (shift) {
        for (auto& v : arr) v-=shift;
    }
}
