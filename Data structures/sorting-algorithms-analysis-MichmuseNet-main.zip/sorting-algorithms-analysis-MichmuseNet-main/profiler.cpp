#include"profiler.h"
#include<windows.h>
#include<psapi.h>
#include<chrono>
#include<iostream>
#include<iomanip>
#include<string>

static std::chrono::high_resolution_clock::time_point g_startTime;
static std::string g_algorithmName="<algorithm>";
void setAlgorithmName(const std::string&name){g_algorithmName=name;}
void startProfiling(){g_startTime=std::chrono::high_resolution_clock::now();std::cout<<"Profiling started."<<std::endl;}
static long long getMemoryUsageMB(){
PROCESS_MEMORY_COUNTERS_EX pmc{};
if(GetProcessMemoryInfo(GetCurrentProcess(),reinterpret_cast<PPROCESS_MEMORY_COUNTERS>(&pmc),sizeof(pmc))){
unsigned long long bytes=pmc.WorkingSetSize;
return static_cast<long long>((bytes+(1<<20)-1)/(1<<20));
}
return 0;
}

void stopProfiling(){
auto end=std::chrono::high_resolution_clock::now();
auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(end-g_startTime).count();
long long memMB=getMemoryUsageMB();
std::cout<<"Profiling stopped. Duration: "<<ns<<" nanoseconds."<<std::endl;
std::cout<<"========================================\n";
std::cout<<"| My Profiler       |  program_name    |\n";
std::cout<<"|-------------------|------------------|\n";
auto printRow=[](const std::string&left,const std::string&right){
std::cout<<"| "<<std::left<<std::setw(18)<<left<<"| "<<std::left<<std::setw(16)<<right<<"|\n";
};

printRow("Sorting Algorithm",g_algorithmName);
printRow("Execution Time",std::to_string(ns)+" nanoseconds");
printRow("Memory Usage",std::to_string(memMB)+" MB");
std::cout<<"========================================\n";
}
