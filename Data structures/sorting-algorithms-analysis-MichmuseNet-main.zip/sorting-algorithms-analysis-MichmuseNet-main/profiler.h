#ifndef PROFILER_H
#define PROFILER_H

void startProfiling();
void stopProfiling();

#endif // PROFILER_H
