#include"profiler.h"
#include"sorting.h"
#include<iostream>
#include<vector>
#include<random>
#include<string>

extern void setAlgorithmName(const std::string&);

int generateRandomInt(int min,int max){static std::mt19937 rng{std::random_device{}()};std::uniform_int_distribution<int>dist(min,max);return dist(rng);}
int main(int argc,char**argv){
std::vector<int>arr;
int N=(argc>2&&std::string(argv[1])=="--size")?std::stoi(argv[2]):10000000;

for(int i=0;i<N;i++)arr.push_back(generateRandomInt(0,10000000));

std::string algo=(argc>1)?argv[1]:"quick-sort";
setAlgorithmName(algo);

std::cout<<"Hello from main!"<<std::endl;
startProfiling();

if(algo=="bubble-sort")bubbleSort(arr);

else if(algo=="selection-sort")selectionSort(arr);
else if(algo=="insertion-sort")insertionSort(arr);

else if(algo=="merge-sort")mergeSort(arr);
else if(algo=="quick-sort")quickSort(arr);
else if(algo=="shell-sort")shellSort(arr);
else if(algo=="heap-sort")heapSort(arr);
else if(algo=="bucket-sort")bucketSort(arr);
else{std::cerr<<"Unknown algorithm: "<<algo<<"\n";return 1;}

stopProfiling();
return 0;
}
