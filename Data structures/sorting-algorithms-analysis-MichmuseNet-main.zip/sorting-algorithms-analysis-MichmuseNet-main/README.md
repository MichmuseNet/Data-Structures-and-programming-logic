[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/-1HAIb3s)
# Sorting Algorithms Analysis

On this coding excersice you will be analyzing 8 common sorting algorithms. Make sure that you document you conclusions in the [Conclusions](#conclusions) section.

Follow instructions from the `Let's code` section at:
https://talks.obedmr.com/content/data-structures/sorting/sorting.html

Include your profile code that you implemented at [ds-profiler](https://github.com/CodersSquad/ds-profiler).

Here the list of sorting algorithms that must be implemented in the [sorting.cpp](./sorting.cpp) file. Don't modify the functions definition.

- Bubble Sort
- Selection Sort
- Insertion Sort
- Merge Sort
- Quick Sort
- Shell Sort
- Heap Sort
- Bucket Sort

## How your program will be tested

**Manual Testing** (please follow the given output format)

Below some examples of executions:

```
./main --algorithm bubble-sort
./main --algorithm bubble-sort 
./main --algorithm selection-sort 
./main --algorithm merge-sort 
./main --algorithm quick-sort 
./main --algorithm shell-sort 
./main --algorithm heap-sort 
./main --algorithm bucket-sort 
```

**With Automation (this is how the professor will test)**

```
make test
```

## Expected Output (of the profiler)

Alongside the `profiler` output, the sorting algorithm should be displayed. Below an example.

```
========================================
| My Profiler       |  program_name    |
|-------------------|------------------|
| Sorting Algorithm | <algorithm_name> |
| Execution Time    | 125 nanoseconds  |
| Memory Usage      | 1 MB             |
========================================
```

## Conclusions
Graph of time in nanoseconds vs sorting method in percentage
<img width="809" height="374" alt="Hoja de cálculo sin título - Hojas de cálculo de Google - Google Chrome 22_09_2025 16_56_45" src="https://github.com/user-attachments/assets/e7182d7e-2b74-4b38-a158-5dd7e08320d7" />

The pie chart shows a clear visualization of the execution times across the sorting methods, it is clear that two algorithms dominate the chart, the selection sort with 66.4% and the bubble sort with 25.9%, togheter account over 90% of the total execution time. On the other hand, insertion sort took 6.5% less, in contrast, the O(n log n) algorithms like merge sort, quick sort, shell sort, heap sort and bucket sort barely register in the chart, representing less than 1%.

My expectations about this program.

Before running these methods i expected that quick sort would be the fastest by the reputation it has about being efficient, the other i expected to be fast was merge sort the reason of this is due to the divide and conquer stratergy. However the results show that bucket sort was the fastest method of all. Bucket sort can achieve near O(n) performance when data is uniformly distributed, it's ability to distribute elements into buckets, sort smaller groups, and the combine them efficiently explains its leading performance.

Results:
<img width="351" height="960" alt="sorting h - Nueva carpeta (2) - Visual Studio Code 22_09_2025 16_58_12" src="https://github.com/user-attachments/assets/b59d7091-8c80-45df-bc8b-372506b87b81" />

In conclusion, the experiment confirms that O(n^2) algorithms are highly inefficient for large datasets, among the efficient methods, bucket-sort is an excellent choice, quick sort, heap sort, merge sort and shell sort all remain strong and consistentperformers with runtimes magnitudes lower than the quadratic algorithms.


## Grading Policy
| Rubric                 | Points |
|------------------------|--------|
| Sorting Algorithms (8) | 50     |
| Conclusions            | 50     |
| Total                  | 100    |
