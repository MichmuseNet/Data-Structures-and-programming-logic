//linked list.h
#pragma once
#include <stdexcept>

namespace linked_list {

template <typename T>
class List {
private:
    struct Node {
        T data;
        Node* prev;
        Node* next;
        explicit Node(const T& value) : data(value), prev(nullptr), next(nullptr) {}
    };

    Node* head_=nullptr;
    Node* tail_=nullptr;
    int size_=0;

public:
    List()=default;

    ~List() {
        while (head_) {
            Node* tmp=head_;
            head_ =head_->next;
            delete tmp;
        }
    }

    void push(const T& value) {
        Node* n=new Node(value);
        if (!tail_) {
            head_=tail_ =n;
        } else {
            tail_->next =n;
            n->prev =tail_;
            tail_ =n;
        }
        ++size_;
    }

    T pop() {
        if (!tail_) throw std::runtime_error("Empty list");
        Node* n = tail_;
        T value = n->data;
        tail_ = tail_->prev;
        if (tail_) tail_->next = nullptr;
        else head_ = nullptr;
        delete n;
        --size_;
        return value;
    }

    T shift() {
        if (!head_) throw std::runtime_error("Empty list");
        Node* n = head_;
        T value = n->data;
        head_ = head_->next;
        if (head_) head_->prev = nullptr;
        else tail_ = nullptr;
        delete n;
        --size_;
        return value;
    }

    void unshift(const T& value) {
        Node* n = new Node(value);
        if (!head_) {
            head_ = tail_ = n;
        } else {
            n->next = head_;
            head_->prev = n;
            head_ = n;
        }
        ++size_;
    }

    int count() const { return size_; }

    bool erase(const T& value) {
        Node* cur = head_;
        while (cur) {
            if (cur->data == value) {
                if (cur->prev) cur->prev->next = cur->next;
                else head_ = cur->next;

                if (cur->next) cur->next->prev = cur->prev;
                else tail_ = cur->prev;

                delete cur;
                --size_;
                return true;
            }
            cur = cur->next;
        }
        return false;
    }
};

}
