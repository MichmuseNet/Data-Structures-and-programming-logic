#ifndef EXPRESSIONS_CALCULATOR_H
#define EXPRESSIONS_CALCULATOR_H
#include <string>
#include <vector>

namespace expr_calc {
std::vector<std::string> infix_to_postfix(const std::string& infix);
double evaluate_postfix(const std::vector<std::string>& postfix);
std::string postfix_to_compact_string(const std::vector<std::string>& postfix);

}

#endif