#include "expressions_calculator.h"
#include <stack>
#include <sstream>
#include <cctype>
#include <cmath>
#include <stdexcept>
using namespace std;
namespace expr_calc {
static int precedence(const string& op) {
    if (op == "^") return 4;
    if (op == "*" || op == "/" || op == "%") return 3;
    if (op == "+" || op == "-") return 2;
    return 0;
}
static bool is_right_associative(const string& op) {
    return op == "^";
}
static bool is_operator_char(char c) {
    return c=='+'||c=='-'||c=='*'||c=='/'||c=='^'||c=='%';
}
static vector<string> tokenize_with_unary(const string& s) {
    vector<string> tokens;
    size_t i = 0;
    while (i < s.size()) {
        if (isspace((unsigned char)s[i])) { ++i; continue; }
        char c = s[i];
        if (isdigit((unsigned char)c) || c=='.') {
            size_t j = i;
            while (j < s.size() && (isdigit((unsigned char)s[j]) || s[j]=='.')) ++j;
            tokens.push_back(s.substr(i, j - i));
            i = j;
        } else if (c == '(' || c == ')') {
            tokens.push_back(string(1, c));
            ++i;
        } else if (is_operator_char(c)) {
            if (c == '-') {
                bool unary = false;
                if (tokens.empty()) unary = true;
                else {
                    string prev = tokens.back();
                    if (prev == "(" || is_operator_char(prev[0])) unary = true;
                }
                if (unary) {
                    tokens.push_back("0");
                    tokens.push_back("-");
                    ++i;
                    continue;
                }
            }
            tokens.push_back(string(1, c));
            ++i;
        } else {
            throw runtime_error(string("Invalid character in expression: '") + c + "'");
        }
    }
    return tokens;
}
vector<string> infix_to_postfix(const string& infix) {
    vector<string> output;
    stack<string> st;
    vector<string> tokens = tokenize_with_unary(infix);
    for (const string& tok : tokens) {
        if (tok.empty()) continue;
        if (isdigit((unsigned char)tok[0]) || (tok.size()>1 && isdigit((unsigned char)tok[1]))) {
            output.push_back(tok);
        } else if (tok == "(") {
            st.push(tok);
        } else if (tok == ")") {
            while (!st.empty() && st.top() != "(") {
                output.push_back(st.top());
                st.pop();
            }
            if (st.empty()) throw runtime_error("Mismatched parentheses");
            st.pop();
        } else {
            string op1 = tok;
            while (!st.empty()) {
                string op2 = st.top();
                if (op2 == "(") break;
                int p1 = precedence(op1);
                int p2 = precedence(op2);
                if ((is_right_associative(op1) && p1 < p2) ||
                    (!is_right_associative(op1) && p1 <= p2)) {
                    output.push_back(op2);
                    st.pop();
                } else break;
            }
            st.push(op1);
        }
    }
    while (!st.empty()) {
        if (st.top() == "(" || st.top() == ")") throw runtime_error("Mismatched parentheses");
        output.push_back(st.top());
        st.pop();
    }
    return output;
}
double evaluate_postfix(const vector<string>& postfix) {
    stack<double> st;
    for (const string& tok : postfix) {
        if (tok.empty()) continue;
        if (isdigit((unsigned char)tok[0]) || tok[0]=='.' || (tok.size()>1 && tok[0]=='-' && isdigit((unsigned char)tok[1]))) {
            double val = stod(tok);
            st.push(val);
        } else {
            if (st.size() < 2) throw runtime_error("Invalid postfix expression");
            double right = st.top(); st.pop();
            double left  = st.top(); st.pop();
            double res = 0.0;
            if (tok == "+") res = left + right;
            else if (tok == "-") res = left - right;
            else if (tok == "*") res = left * right;
            else if (tok == "/") {
                if (right == 0.0) throw runtime_error("Division by zero");
                res = left / right;
            } else if (tok == "^") {
                res = pow(left, right);
            } else if (tok == "%") {
                if (right == 0.0) throw runtime_error("Modulo by zero");
                res = fmod(left, right);
            } else throw runtime_error("Unknown operator: " + tok);
            st.push(res);
        }
    }
    if (st.size() != 1) throw runtime_error("Invalid postfix evaluation");
    return st.top();
}
string postfix_to_compact_string(const vector<string>& postfix) {
    string out;
    for (const string& t : postfix) out += t;
    return out;
}
}